<?php

require_once 'db_config.php';
require_once 'functions.php';
/**
 * Vérifier si 
 */


if (!empty($_POST['valider'])) {

    $no_errors = empty(form_validation($_POST));

    // Si le tableau des erreurs n'est pas vide
    if ($no_errors === false) {

        // Débuter la session
        session_start();

        // Affection des erreur dans la variable de session
        $_SESSION['flash'] = form_validation($_POST);

        // Redirection vers le formulaire
        header('Location: registration.php');
        exit;
    }

    // s'il n'y a pas d'erreur on execute le code ci-dessous
    $fichier = null;

    if (!empty($_FILES['photo']['name'])) {

        // Récupération de l'image
        $image = $_FILES['photo']['name'];
        $destination = 'profils/'.$image;
        move_uploaded_file($_FILES['photo']['tmp_name'], $destination);

        $fichier = $destination;
    }

    // Insérer les données dans la base de données
    $statement = $db->prepare(
        'INSERT INTO etudiant VALUES (
            NULL, :nom,
            :prenom, :sexe,
            :adresse, :date_naiss,
            :lieu_naiss, :email,
            :telephone, :description,
            :photo, :conditions,
            :id_Filiere)'
    );

    // On lie les propriétés avec les valeurs
    $statement->bindValue(':nom', $_POST['nom'], PDO::PARAM_STR);
    $statement->bindValue(':prenom', $_POST['prenom'], PDO::PARAM_STR);
    $statement->bindValue(':sexe', $_POST['sexe']);
    $statement->bindValue(':adresse', $_POST['adresse'], PDO::PARAM_STR);
    $statement->bindValue(':date_naiss', $_POST['date_naiss']);
    $statement->bindValue(':lieu_naiss', $_POST['lieu_naiss'], PDO::PARAM_STR);
    $statement->bindValue(':email', $_POST['email']);
    $statement->bindValue(':telephone', $_POST['telephone'], PDO::PARAM_STR);
    $statement->bindValue(':description', $_POST['description'], PDO::PARAM_STR);
    $statement->bindValue(':photo', $fichier, PDO::PARAM_STR);
    $statement->bindValue(':conditions', $_POST['conditions']);
    $statement->bindValue(':id_Filiere', $_POST['id_Filiere']);
    
    // execution de la requete
    $statement->execute();

    // récupération de l'id du dernier étudiant enregistré
    $student_id = $db->lastInsertId();

    session_start();

    $_SESSION['student'] = select($db, $student_id, 'etudiant');
    $_SESSION['student']['filiere'] = select($db, $_SESSION['student']['id_Filiere'], 'filiere');
    header('Location: success.php');
}
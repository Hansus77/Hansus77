<?php
session_start();
require_once 'db_config.php';
require_once 'functions.php';

try {

    $filieres = selectAll($db, 'filiere');
    $niveaux  = selectAll($db, 'niveau');

} catch (\PDOException $except) {
    
    echo 'ERREUR: '.$except->getMessage();
}

?>

<!DOCTYPE html>
<html lang="FR-fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.7/css/all.css">
    <link rel="stylesheet" href="https://unpkg.com/swiper/css/swiper.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Inscription</title>
</head>
<body>
    <header id="top">
        <div class="container">
            <p id="logo"><img src="img/Logo.png" alt="logo" width="145" height="21"></p>
            <nav>
                <a href="index.html">Accueil</a>
                <a href="#">A propos de nous</a>
                <a href="#" class="active">S'inscrire</a>
            </nav>
        </div>
        <section class="min-banner">
                <h1>INSCRIPTION</h1>
        </section>
    </header>

    <main>

        <?php if (isset($_SESSION['flash'])) : ?>
            <ul class = "container alert">
                <?php foreach($_SESSION['flash'] as $error): ?>
                 <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
            <?php unset($_SESSION['flash']); session_destroy();?>
        <?php endif ?>
        <form action="signup.php" method="POST" id = "logup" enctype="multipart/form-data">
            <fieldset>
                <legend>Informations personnelles</legend>
                <hr>
                <div class="row">
                    <div class="form-group">
                        <label for="nom">Nom <span title="obligatoire" class="required">*</span></label>
                        <input class="form-control" required type="text" name="nom" id="nom">
                    </div>
                    <div class="form-group">
                        <label for="prenom">Prénom <span title="obligatoire" class="required">*</span></label>
                        <input class="form-control" type="text" required name="prenom" id="prenom">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label>Sexe <span title="obligatoire" class="required">*</span></label>
                        <div class="radio-group">
                            <label for="homme">
                                <input type="radio" name="sexe" id="homme" value = "h">
                                Homme
                            </label>
                            <label for="femme">
                                <input type="radio" name="sexe" id="femme" value = "f">
                                Femme
                            </label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="date_naiss">Date de naissance <span title="obligatoire" class="required">*</span></label>
                        <input class="form-control" type="date" name="date_naiss" required id="date_naiss">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label for="lieu_naiss">Lieu de naissance <span title="obligatoire" class="required">*</span></label>
                        <input class="form-control" required type="text" name="lieu_naiss" id="lieu_naiss">
                    </div>
                    <div class="form-group">
                        <label for="adresse">Adresse</label>
                        <input class="form-control" type="text" name="adresse" id="adresse">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label for="id_Filiere">Filieres <span title="obligatoire" class="required">*</span></label>
                        <select class="form-control" name = "id_Filiere" id="id_Filiere" required>
                            <?php foreach($filieres as $filiere): ?>
                                <option value="<?= $filiere->id ?>"> <?= $filiere->libelle ?> </option>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="niveau">Niveau <span title="obligatoire" class="required">*</span></label>
                        <select class="form-control" name="niveau" id="niveau" required>
                            <?php foreach($niveaux as $niveau):?>
                                <option value="<?= $niveau->id ?>" > <?= $niveau->libelle ?> </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label for="telephone">Numéro de téléphone</label>
                        <input class="form-control" type="tel" name="telephone" id="telephone">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input class="form-control" type="email" name="email" id="email">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label for="description">Décrivez-vous en quelques mots</label>
                        <textarea class="form-control" name="description" id="description" cols="30" rows="10"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="photo">Insérer votre photo</label>
                        <input class="form-control" accept=".jpg,.png" type="file" name="photo" id="photo">
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <legend>Informations des parents</legend>
                <hr>
                <div class="row">
                    <div class="form-group">
                        <label for="nom_parent">Nom du père</label>
                        <input class="form-control" type="text" name="nom_parent[]" id="nom_parent">
                    </div>
                    <div class="form-group">
                        <label for="nom_parent">Nom de la mère</label>
                        <input class="form-control" type="text" name="nom_parent[]" id="nom_parent">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label for="profession_parent">Profession du père</label>
                        <input class="form-control" type="text" name="profession_parent[]" id="profession_parent">
                    </div>
                    <div class="form-group">
                        <label for="profession_parent">Profession de la mère</label>
                        <input class="form-control" type="text" name="profession_parent[]" id="profession_parent">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group">
                        <label for="numero_parent">Numéro du père</label>
                        <input class="form-control" type="text" name="numero_parent[]" id="numero_parent">
                    </div>
                    <div class="form-group">
                        <label for="numero_parent">Numéro de la mère</label>
                        <input class="form-control" type="tel" name="numero_parent[]" id="numero_parent">
                    </div>
                </div>
                <label for="conditions">
                    <input type="checkbox" name="conditions" id="conditions" value="1" required>
                    Vous accepter les <a href="#" style="color:var(--violet);text-decoration:underline;">termes</a> et conditions
                    <span title="obligatoire" class="required">*</span>
                </label>
                <div class="form-group">
                    <button class="btn-form" type="submit" name="valider" value = "ok">
                        Enregistrer
                    </button>
                </div>
            </fieldset>
        </form>
    </main>

    <footer>
        <div class="container">

            <div class="footer-card">
                <h4 class="card-title"><span><img src="img/Logo.png" alt="logo" width="250" height="70"></span></h4>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Similique, blanditiis quae saepe aut eaque neque!</p>
                <div class="card-footer">
                    <ul>
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-card">
                <h4 class="card-title">Nous contacter</h4>
                <hr>
                <ul>
                    <li><i class="fa fa-headphones"></i> <a href="tel:066069791">066069791</a></li>
                    <li><i class="fa fa-envelope"></i> <a href="mailto:hansusuniversity@gmail.com.com">hansusuniversity@gmail.com</a></li>
                    <li><i class="fa fa-location-arrow"></i> Gabon, Libreville</li>
                </ul>
            </div>
            <div class="footer-card">
                <h4 class="card-title">Lien utiles</h4>
                <hr>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. <br> Similique, blanditiis quae saepe aut eaque neque!</p>
            </div>
            <div class="footer-card">
                <h4 class="card-title">Newsletter</h4>
                <hr>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. <br> Similique, blanditiis quae saepe aut eaque neque!</p>
                <form class="newsletter">
                    <input type="email"  required placeholder="Entrez votre email">
                    <button type="submit">Souscrire</button>
                </form>
            </div>
        </div>
        <p class="last"><small>@2020 University. All rights reserved. Created by Hansus</small></p>
    </footer>
    <!-- script js -->
    <script src="https://unpkg.com/swiper/js/swiper.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
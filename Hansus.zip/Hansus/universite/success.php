<?php session_start(); ?>

<!DOCTYPE html>
<html lang="FR-fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.7/css/all.css">
    <link rel="stylesheet" href="https://unpkg.com/swiper/css/swiper.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Page de succès</title>
</head>
<body>
    <header id="top">
        <div class="container">
            <p id="logo"><img src="img/Logo.png" alt="logo" width="145" height="21"></p>
            <nav>
                <a href="index.html">Accueil</a>
                <a href="#">A propos de nous</a>
                <a href="registration.php">S'inscrire</a>
            </nav>
        </div>
        <section class="min-banner">
                <h1>INSCRIPTION REUSSIE</h1>
        </section>
    </header>

    <main class = "container" style ="text-align: center;">
        <p style = "margin:30px auto;">
            Felicitation M(me). <span style = "font-weight:bold;"> <?= $_SESSION['student']['nom'] ?> <?= $_SESSION['student']['prenom'] ?></span>. Vous êtes inscrit dans la filière
            <strong><?= $_SESSION['student']['filiere']['libelle'] ?></strong>
        </p>
        <a href="index.html" class = "btn"  style = "width:300px;color:white;margin:20px auto;">Retour à la page d'accueil</a>
    </main>
    <?php unset($_SESSION['student']); session_destroy();?>
    <footer>
        <div class="container">

            <div class="footer-card">
                <h4 class="card-title"><span><img src="img/Logo.png" alt="logo" width="250" height="70"></span></h4>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Similique, blanditiis quae saepe aut eaque neque!</p>
                <div class="card-footer">
                    <ul>
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-card">
                <h4 class="card-title">Nous contacter</h4>
                <hr>
                <ul>
                    <li><i class="fa fa-headphones"></i> <a href="tel:066069791">066069791</a></li>
                    <li><i class="fa fa-envelope"></i> <a href="mailto:hansusuniversity@gmail.com.com">hansusuniversity@gmail.com</a></li>
                    <li><i class="fa fa-location-arrow"></i> Gabon, Libreville</li>
                </ul>
            </div>
            <div class="footer-card">
                <h4 class="card-title">Lien utiles</h4>
                <hr>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. <br> Similique, blanditiis quae saepe aut eaque neque!</p>
            </div>
            <div class="footer-card">
                <h4 class="card-title">Newsletter</h4>
                <hr>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. <br> Similique, blanditiis quae saepe aut eaque neque!</p>
                <form class="newsletter">
                    <input type="email"  required placeholder="Entrez votre email">
                    <button type="submit">Souscrire</button>
                </form>
            </div>
        </div>
        <p class="last"><small>@2020 University. All rights reserved. Created by Hansus</small></p>
    </footer>
    <!-- script js -->
    <script src="https://unpkg.com/swiper/js/swiper.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
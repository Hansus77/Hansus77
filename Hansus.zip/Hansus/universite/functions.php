<?php
/**
 * Toutes les fonctions du site
 */

function select($db, $id, $table)
{
    $query = "SELECT * FROM $table WHERE id = $id";
    $statement = $db->query($query);
    return $statement->fetch(PDO::FETCH_ASSOC);
}

function selectAll($db, $table)
{
    $query = "SELECT * FROM $table";
    $statement = $db->query($query);
    return $statement->fetchAll(PDO::FETCH_OBJ);
}

function form_validation($post)
{
    // Extraction des index du tableau en variables
    extract($post);
    $errors = [];
    
    //Verifie si le nom a au moins 2 caractères
    if (strlen($nom) < 2 ) {
        $errors[] = 'le nom nécessite au moins 2 caractères';
    }

    //Verifie si le prénom a au moins 2 caractères
    if (strlen($prenom) < 2) {
        $errors[] = 'le prénom nécessite au moins 2 caractères';
    }

    return $errors;
}
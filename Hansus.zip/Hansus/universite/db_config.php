<?php
/**
 * Configuration de la base de données
 */
define('DSN', 'mysql:dbname=universite;host=127.0.0.1');
define('USER', 'root');
define('PASSWORD', '');

$options = [
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8',
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
];
$db = new PDO(DSN, USER, PASSWORD, $options);